package mvc.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import mvc.dto.Contact;

public class ContactModel {
	
	//DBConnection code is here which insert the contact details in database
	
	public boolean save(Contact contact) {
		boolean result=false;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/phbook","root","01082005");
			PreparedStatement stmt=con.prepareStatement("Insert into contacts (name,phnumber,blocked,createdon) values (?,?,?,Current_timestamp)");
			stmt.setString(1, contact.getName());
			stmt.setString(2, contact.getPhNumber());
			stmt.setBoolean(3, contact.isBlocked());
			int count=stmt.executeUpdate();
			result=count>0;
			con.close();
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
		
		
	}
	
	
	// data list madhe store karun viewContact.jsp la pathavaycha aahe 
	// tyasathi aadhi to data Contact class cha objevct madhe setter method cha use karun store kela aani nntr to Contact cha object List madhe store kela aani List ViewController la return keli 
	public List<Contact> getAll(){
		List<Contact> contactList=new ArrayList();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/phbook","root","01082005");
			PreparedStatement stmt=con.prepareStatement("Select * from contacts");
			ResultSet rs=stmt.executeQuery();
			while(rs.next()) {
				Contact ct=new Contact();
				ct.setId(rs.getInt("id"));
				ct.setName(rs.getString("name"));
				ct.setPhNumber(rs.getString("phnumber"));
				ct.setBlocked(rs.getBoolean("blocked"));
				ct.setCreatedOn(rs.getString("createdon"));
				contactList.add(ct);
			}
			con.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generted catch block
			e.printStackTrace();
		}
		return contactList;
	}

}
