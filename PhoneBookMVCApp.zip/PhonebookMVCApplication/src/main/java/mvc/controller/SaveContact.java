package mvc.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import mvc.dto.Contact;
import mvc.model.ContactModel;

import java.io.IOException;

/**
 * Servlet implementation class SaveContact
 */
@WebServlet("/SaveContact")
public class SaveContact extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String name=request.getParameter("name");
		String contact=request.getParameter("contact");
		String blocked=request.getParameter("blocked");
		boolean blockFlag=blocked!=null;// if block is null it returns false, if block is not null it returns true
		
		Contact contactObject=new Contact();
		contactObject.setName(name);
		contactObject.setPhNumber(contact);
		contactObject.setBlocked(blockFlag);
		
		ContactModel contactModel=new ContactModel();
		boolean result=contactModel.save(contactObject);
		String message =result?"created":"fail";
		response.sendRedirect("newcontact.jsp?msg="+message);
		
	}

}
