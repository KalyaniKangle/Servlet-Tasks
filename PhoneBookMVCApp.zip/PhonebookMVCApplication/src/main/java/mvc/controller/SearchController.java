package mvc.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


@WebServlet("/SearchController")
public class SearchController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
				
		String name=request.getParameter("name");
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/phbook","root","01082005");
			PreparedStatement stmt=con.prepareStatement("select name,phnumber,blocked from contacts where name=?");
			stmt.setString(1,name);
			ResultSet rs=stmt.executeQuery();
			out.print("<table>"
					+ "<thead>"
					+ "<tr>"
					+ "<th>Name</th>"
					+ "<th>Phone Number</th>"
					+ "<th>Blocked</th>"
					+ "</thead>"
					+ "</table>"
					);
			while(rs.next()) {
				out.print("<table>"
						+"<tr>"
						+ "<td>"+rs.getString("name")+"</td>"
						+ "<td>"+rs.getString("phnumber")+"</td>"
						+ "<td>"+rs.getString("blocked")+"</td>"
						+ "</tr>"
						+ "</table>"
						);
			}
			
			con.close();
			
			} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
