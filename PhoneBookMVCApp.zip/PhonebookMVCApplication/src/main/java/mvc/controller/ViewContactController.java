package mvc.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import mvc.dto.Contact;
import mvc.model.ContactModel;

import java.io.IOException;
import java.util.List;

/**
 * Servlet implementation class ViewContactController
 */
@WebServlet("/ViewContactController")
public class ViewContactController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// ContactModel class chi method call karnyastahi tya class cha object tayar kela aani tya object ne tya class chi method call keli 
		// aani tya method cha result List<Contact> cha object madhe store kela
		
		ContactModel model=new ContactModel();
		List<Contact> contacts=model.getAll();
		
		
		/*
		 * for(Contact c:contacts) { System.out.println(c); }
		 */
		
		
		request.setAttribute("contactList", contacts);
		
		// viewContact.jsp la to data transfer karaycha aahe tya sathi viewContact.jsp la request send karnar aani tya request madhe setAttribut() cha use karun data set karnar
		// setParameter() ashi kontich methiod exist karat nahi tya mule request cha through je ekadya page kade data cha object pathavaycha asel tr request.setAttribute() use honar  
		
		// request dispatcher is used bcoz we are transferring same data to viewContact.jsp
		
		RequestDispatcher dis=request.getRequestDispatcher("viewcontact.jsp");
		dis.forward(request, response);
		
		RequestDispatcher dis1=request.getRequestDispatcher("EditController");
		dis1.forward(request, response);
		
		
		//RequestDispatcher dis=request.getRequestDispatcher("view.jsp");
		//dis.forward(request, response);
	}

}
