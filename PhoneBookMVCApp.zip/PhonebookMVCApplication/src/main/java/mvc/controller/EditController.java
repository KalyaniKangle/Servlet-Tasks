package mvc.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import mvc.dto.Contact;
import mvc.model.ContactModel;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

/**
 * Servlet implementation class EditController
 */
@WebServlet("/EditController")
public class EditController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		PrintWriter out=response.getWriter();
		
//		Contact c=new Contact();
//		int id=c.getId();
//		String i = String.valueOf(id) ;
//		String id1=request.getParameter(i);
		
		String id2=request.getParameter("id");
		
		RequestDispatcher dis=request.getRequestDispatcher("edit.jsp");
		dis.forward(request, response);
		
		
//		String id2=request.getParameter("id");
        String name=request.getParameter("name");
        String phno=request.getParameter("phno");
        String blocked=request.getParameter("status");
        
        Boolean status=Boolean.parseBoolean(blocked);
		
		
		
//		RequestDispatcher dis=request.getRequestDispatcher("edit.jsp");
//		dis.forward(request, response);
//		
//		
//		

		/*
		 * ContactModel model1=new ContactModel(); List<Contact>
		 * contact=model1.getAll();
		 * 
		 * request.setAttribute("contactList", contact);
		 * 
		 * 
		 * List<Contact> contacts = (List<Contact>) request.getAttribute("contactList");
		 * 
		 * String name=null; String phno=null; Boolean blocked = null;
		 * 
		 * for(Contact ct:contacts) { System.out.println(ct); name=ct.getName();
		 * phno=ct.getPhNumber(); blocked=ct.isBlocked(); }
		 */
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/phbook","root","01082005");
			PreparedStatement stmt=con.prepareStatement("Update  contacts set name=? , phnumber=? , blocked=? where id=?");
			stmt.setString(1, name);
			stmt.setString(2, phno);
			stmt.setBoolean(3, status);
			stmt.setString(4, id2);
			out.print("Updated");
			int count=stmt.executeUpdate();
			con.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

}