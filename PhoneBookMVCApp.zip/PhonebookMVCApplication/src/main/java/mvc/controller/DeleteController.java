package mvc.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import mvc.dto.Contact;
import mvc.model.ContactModel;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

/**
 * Servlet implementation class DeleteController
 */
@WebServlet("/DeleteController")
public class DeleteController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
	String id=request.getParameter("id");
		int id1=Integer.parseInt(id);
		System.out.println(id);
		Boolean result =false;
		result=DeleteController.delete(id1);
		String msg=result?"Deleted":"fail";

		ContactModel model=new ContactModel();
		List<Contact> contacts=model.getAll();
		request.setAttribute("contactList", contacts);
		RequestDispatcher dis=request.getRequestDispatcher("viewcontact.jsp?msg="+msg);
		dis.forward(request, response);
		
		
		
		
	}
	
	public static Boolean delete(int id1) {
		Boolean result=false;
		Connection con=null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			 con=DriverManager.getConnection("jdbc:mysql://localhost:3306/phbook","root","01082005");
			PreparedStatement stmt=con.prepareStatement("Delete from contacts where id=?");
			stmt.setInt(1, id1);
			int count=stmt.executeUpdate();	
			result=count>0;
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		return result;
	}
	

}
