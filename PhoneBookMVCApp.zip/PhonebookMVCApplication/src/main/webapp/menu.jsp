<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Phonebook MVC Application</title>
</head>
<body>

<% // we can use bootstrap to make the application responsive and bring it look and feel
// we add navigation bar here using bootstrap
%>


<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
<div class="container-fluid">
<ul class="navbar-nav">
<li class="nav-item">
<a class="nav-link active" href="home.jsp">Home</a>
</li>
<li class="nav-item">
<a class="nav-link" href="newcontact.jsp">Create Contact</a>
</li>
<li class="nav-item" >
<a class="nav-link" href="ViewContactController">View Contact</a>
</li>
<li class="nav-item">
<a class="nav-link" href="search.jsp">Search Contact</a>

</li>
</ul>
</div>
</nav>





<!-- <hr/>
<center>
<h2>

<a href="home.jsp">Home</a>
<a href="#">New Contact</a>
<a href="#">View</a>
<a href="#">Search</a>
</h2>

</center>
<hr/> -->

</body>
</html>