<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>View Contact Details</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
<%@ page import="java.util.*" %>
<%@ page import="mvc.dto.Contact" %>
<%@ include file='menu.jsp' %>

<%
String msg=request.getParameter("msg");
String msgClass="";
String msgValue="";
if(msg!=null){
	switch(msg){
	case "Deleted":
		msgClass="alert alert-success";
		msgValue="Contact Delete Successfully..";
		break;
	case "fail":
		msgClass="alert alert-danger";
		msgValue="Fail to Delete Contact";
		break;
	}
}
%>
<div class="<%=msgClass%>">
<strong><%=msgValue%></strong>



<% 
List<Contact> contact = (List<Contact>) request.getAttribute("contactList"); // casting is done bcoz request.getAttribute() returns object type of value
%>
<div class="container">
  
          
  <table class="table table-hover">
    <thead>
      <tr>
        <th>Name</th>
        <th>Contact Number</th>
        <th>Blocked</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
     
      <%
      for(Contact ct:contact)
      {
      %>
      
      <tr>
      <td><%=ct.getName() %></td>
       <td><%=ct.getPhNumber() %></td>
       <td><%=ct.isBlocked() %></td>
       
       <td>
       <a href="EditController?id=<%=ct.getId() %>">
       <span class="glyphicon glyphicon-edit"></span>
      
      
       </a>
        <a href="DeleteController?id=<%=ct.getId()%>">
                        <span class="glyphicon glyphicon-trash"></span>
                      </a>
                      </td>
                      </tr>
                      
                      <%
                      System.out.println(ct.getId()); 
      }
                      %>
       
     
      
      
    </tbody>
  </table>
</div>


</body>
</html>