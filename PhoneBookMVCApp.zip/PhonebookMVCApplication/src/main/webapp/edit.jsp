<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>

<center>
<form action='EditController'>
Enter Name : <input type='text' name='name'>
<br/><br/>
Enter Phone number : <input type='text' name='phno'>
<br/><br/>
Enter status (Block/Unblock) : <input type='text' name='status'>
<br/><br/>
<button type='submit'>Submit</button>


</form>
</center>

</body>
</html>