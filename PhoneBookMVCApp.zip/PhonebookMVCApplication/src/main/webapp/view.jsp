<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<%@ page import="java.util.*" %>
<%@ page import="mvc.dto.Contact" %>
<html>
<body>
<%@ include file='menu.jsp' %>

<%
    List<Contact> contacts = (List<Contact>) request.getAttribute("contactList");
%>
<div class="container mt-3">
 <h2>Contact List</h2>
  <table class="table table-hover">
    <thead class="table-success ">
      <tr>
        <th>Name</th>
        <th>Contact Number</th>
        <th>Blocked</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <%
          for(Contact ct : contacts ) {
      %>
              <tr>
                  <td><%= ct.getName() %></td>
                  <td><%= ct.getPhNumber() %></td>
                  <td><%= ct.isBlocked()? "Yes" :"No" %></td>
                  <td>
                    <a href="edit-contact?id=<%= ct.getId() %>">
                      <span class="glyphicon glyphicon-edit"></span>
                    </a>
                     <a href="delete-contact?id=<%= ct.getId() %>">
                        <span class="glyphicon glyphicon-trash"></span>
                      </a>
                  </td>
              </tr>
      <%
              }
      %>
    </tbody>
  </table>
</div>


</body>
</html>

</body>
</html>