<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Add Contacts</title>
</head>
<body>
<%@ include file='menu.jsp' %>


<%
String msg=request.getParameter("msg");
String msgClass="";
String msgValue="";
if(msg!=null){
	switch(msg){
	case "created":
		msgClass="alert alert-success";
		msgValue="Contact Created Successfully..";
		break;
	case "fail":
		msgClass="alert alert-danger";
		msgValue="Fail to Create Contact";
		break;
	}
}
%>
<div class="<%=msgClass%>">
<strong><%=msgValue%></strong>



<div class="container mt-3">
<h2>Add New Contacts</h2>
<form action="SaveContact">
<div class="mb-3 mt-3">
<label for="name">Name:</label>
<input type="text" class="form-control"id="name"placeholder="Enter Name" name="name">
</div>
<div class="mb-3">
<label for="contact">Contact:</label>
<input type="text" class="form-control" id="contact" placeholder="Enter Contact Number" name="contact">

</div>
<div class="form-check mb-3">
<label class="form-check-label">
<input class="form-check-input" type="checkbox" name="blocked">Block Contact
</label>
</div>
<button type="submit" class="btn btn-success">Create Contact</button>
</form>
</div>
      
</body>
</html>