<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<div class="container mt-3">
<form action="SearchController">
  <div class="mb-3 mt-3">
    <label for="name" class="form-label">Name:</label>
    <input type="name" class="form-control" id="name" placeholder="Enter name" name="name">
  </div>
  
  <button type="submit" class="btn btn-success">Search</button>
</form>
</div>









<!-- <center>
<div class="container mt-3">
<form action='SearchController'>
<div class="mb-3 mt-3">
<label for="name">Name:</label>
<input type="text" class="form-control"id="name"placeholder="Enter Name" name="name">
<button type="submit" class="btn btn-success">Search</button>
</div>

</form>
</div>
</center>
 -->
</body>
</html>