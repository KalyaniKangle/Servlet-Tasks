<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Phonebook MVC Application</title>
</head>
<body>

<%@ include file='menu.jsp'  %> 

<% // this scriplet tag is only written for writing comments
//here above the tag used for including menu.jsp file is a directive tag , which is used to include another jsp or 
// servlet files inside any of ther jsp or servlet , so  that content of that included file can be added in current file and used there
// we make menu.jsp as a seprate file bcoz we need that menu on every page of application so now we just have to include that menu file whereever required

%>

<center>
<h2>Welcome to Phone Book Application</h2>
</center>
</body>
</html>